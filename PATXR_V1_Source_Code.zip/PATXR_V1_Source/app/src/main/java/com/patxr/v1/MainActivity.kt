package com.patxr.v1

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.AlphaAnimation
import android.view.animation.RotateAnimation
import android.widget.*
import android.graphics.drawable.AnimationDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 5, 15)
    private val panel = Color.rgb(25, 17, 39)
    private val purple = Color.rgb(192, 132, 252)
    private val white = Color.rgb(248, 242, 255)
    private val muted = Color.rgb(190, 171, 212)
    private lateinit var root: FrameLayout
    private lateinit var page: LinearLayout
    private lateinit var body: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int = 18) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        setStroke(dp(1), Color.rgb(91, 48, 126))
    }
    private fun label(s: String, size: Float, color: Int = white, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(2), dp(5), dp(2), dp(5))
        }
    private fun field(hintText: String, multi: Boolean = false) = EditText(this).apply {
        hint = hintText; setHintTextColor(muted); setTextColor(white); textSize = 15f
        setPadding(dp(13), dp(11), dp(13), dp(11)); background = rounded(Color.rgb(39, 27, 54), 12)
        if (multi) { minLines = 3; gravity = Gravity.TOP }
    }
    private fun actionButton(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 14f; setTextColor(Color.BLACK)
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(216, 180, 254), purple)
        ).apply { cornerRadius = dp(13).toFloat() }
        setOnClickListener { action() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home()
    }

    private fun shell(title: String) {
        root = FrameLayout(this)
        root.setBackgroundColor(bg)

        // Anime video is optional: add app/src/main/res/raw/anime_bg.mp4 to enable it.
        // If no video is supplied, use a softly animated purple gradient background.
        val videoId = resources.getIdentifier("anime_bg", "raw", packageName)
        if (videoId != 0) {
            val video = VideoView(this)
            video.setVideoURI(Uri.parse("android.resource://$packageName/$videoId"))
            video.alpha = 0.30f
            video.setOnPreparedListener { mp ->
                mp.isLooping = true
                mp.setVolume(0f, 0f)
                video.start()
            }
            root.addView(video, FrameLayout.LayoutParams(-1, -1))
        } else {
            val animated = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(26, 8, 42), bg, Color.rgb(42, 10, 58), bg)
            )
            animated.cornerRadius = 0f
            root.background = animated
            val glow = View(this)
            glow.background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(60, 192, 132, 252), Color.TRANSPARENT)
            )
            val anim = AlphaAnimation(0.18f, 0.60f).apply {
                duration = 2600; repeatMode = Animation.REVERSE; repeatCount = Animation.INFINITE
            }
            glow.startAnimation(anim)
            root.addView(glow, FrameLayout.LayoutParams(-1, dp(260), Gravity.TOP))
        }

        val scroll = ScrollView(this)
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(15), dp(18), dp(20))
        }
        scroll.addView(page)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.argb(220, 15, 9, 24), 18)
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.patxr_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.BLACK, 12)
            clipToOutline = true
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(58), dp(58)))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label("PATXR V1", 21f, purple, true))
            addView(label("WA TOOLS  •  SAFE MODE", 10f, muted, true))
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(header)
        page.addView(label(title, 26f, white, true).apply { setPadding(0, dp(18), 0, dp(5)) })
        page.addView(label("Hitam • Ungu Neon", 12f, muted))
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(body)
    }

    private fun gap(h: Int = 10) { body.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(14))
        background = rounded(Color.argb(225, 22, 14, 33), 18)
    }
    private fun addCard(v: View) {
        body.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
    }
    private fun backButton() { addCard(actionButton("← Kembali") { home() }) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun home() {
        shell("Dashboard")
        body.addView(label("Selamat datang di PATXR V1", 16f, white, true))
        body.addView(label("Tools teks WhatsApp dengan tampilan anime-style. Tidak mengirim pesan otomatis dan tidak mengganggu akun lain.", 14f, muted))
        gap(12)
        val choices = listOf(
            Triple("✦  Text Generator", "Buat teks dekoratif", { generator() }),
            Triple("✎  Chat Formatter", "Tebal, miring, coret, monospace", { formatter() }),
            Triple("◉  Bug Simulator", "Simulasi visual lokal", { simulator() }),
            Triple("⌕  Info Nomor", "Periksa format nomor internasional", { numberInfo() })
        )
        choices.forEach { (title, desc, open) ->
            val c = card()
            c.addView(label(title, 17f, white, true))
            c.addView(label(desc, 13f, muted))
            c.addView(actionButton("Buka fitur") { open() })
            addCard(c)
        }
        body.addView(label("Video anime bergerak: tambahkan file anime_bg.mp4 ke app/src/main/res/raw/.", 11f, muted))
    }

    private fun generator() {
        shell("Text Generator")
        body.addView(label("Tulis teks, lalu buat versi dekoratif.", 14f, muted))
        gap()
        val input = field("Tulis teks di sini", true); addCard(input)
        val output = field("Hasil teks", true).apply { isFocusable = false }; addCard(output)
        addCard(actionButton("Generate") {
            val s = input.text.toString().trim()
            if (s.isBlank()) toast("Masukkan teks dahulu") else output.setText("꧁༺ ${s.uppercase()} ༻꧂")
        })
        addCard(actionButton("Salin") { copyText(output.text.toString()) })
        addCard(actionButton("Bagikan") { shareText(output.text.toString()) })
        backButton()
    }

    private fun formatter() {
        shell("Chat Formatter")
        body.addView(label("Format teks untuk disalin ke chat.", 14f, muted))
        gap()
        val input = field("Tulis pesan", true); addCard(input)
        val output = field("Hasil format", true).apply { isFocusable = false }; addCard(output)
        listOf(
            "Tebal" to Pair("*", "*"),
            "Miring" to Pair("_", "_"),
            "Coret" to Pair("~", "~"),
            "Monospace" to Pair("```", "```")
        ).forEach { (name, marks) ->
            addCard(actionButton(name) {
                val s = input.text.toString()
                if (s.isBlank()) toast("Masukkan teks dahulu")
                else output.setText(marks.first + s + marks.second)
            })
        }
        addCard(actionButton("Salin hasil") { copyText(output.text.toString()) })
        addCard(actionButton("Bagikan hasil") { shareText(output.text.toString()) })
        backButton()
    }

    private fun simulator() {
        shell("Bug Simulator")
        body.addView(label("Demo tampilan lokal saja. Tidak mengirim bug, payload, atau pesan ke WhatsApp.", 14f, muted))
        gap()
        val status = label("STATUS: READY", 20f, purple, true)
        val c = card(); c.addView(status); c.addView(label("Simulasi hanya mengubah tulisan di layar aplikasi ini.", 13f, muted)); addCard(c)
        addCard(actionButton("Mulai simulasi") {
            status.text = "STATUS: SIMULATED ERROR"
            status.setTextColor(Color.rgb(248, 113, 113))
        })
        addCard(actionButton("Reset") {
            status.text = "STATUS: READY"
            status.setTextColor(purple)
        })
        backButton()
    }

    private fun numberInfo() {
        shell("Info Nomor")
        body.addView(label("Pemeriksaan format saja; tidak mencari pemilik, lokasi, atau status WhatsApp.", 14f, muted))
        gap()
        val input = field("Contoh: +6281234567890")
        input.inputType = android.text.InputType.TYPE_CLASS_PHONE
        addCard(input)
        val result = label("Hasil akan muncul di sini.", 14f, white)
        val c = card(); c.addView(result); addCard(c)
        addCard(actionButton("Periksa format") {
            val s = input.text.toString().trim().replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
            val digits = s.removePrefix("+")
            val valid = s.startsWith("+") && digits.isNotEmpty() && digits.all { it.isDigit() } && digits.length in 8..15
            result.text = if (valid) "Format nomor internasional terlihat valid: $s\n\nIni tidak membuktikan nomor aktif atau terdaftar di WhatsApp."
                else "Format belum valid. Gunakan kode negara, contoh +62..., dan 8–15 digit."
        })
        backButton()
    }

    private fun copyText(s: String) {
        if (s.isBlank()) { toast("Belum ada teks"); return }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("PATXR V1", s))
        toast("Teks disalin")
    }
    private fun shareText(s: String) {
        if (s.isBlank()) { toast("Belum ada teks"); return }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, s)
        }, "Bagikan teks"))
    }
}
