plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.patxr.v1"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.patxr.v1"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
