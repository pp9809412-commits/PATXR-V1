# PATXR V1 — Android source code

Project Android native dengan logo yang diberikan pengguna, tema hitam + ungu neon, dan empat fitur aman.

## Fitur
- Text Generator: teks dekoratif, salin, dan bagikan.
- Chat Formatter: tebal, miring, coret, monospace.
- Bug Simulator: simulasi status error hanya di aplikasi.
- Info Nomor: memeriksa format nomor internasional secara lokal.

## Menambahkan video anime bergerak
Video anime belum disertakan karena pengguna belum memberikan file video. Gunakan video milik sendiri atau yang memiliki izin untuk digunakan.
1. Buat folder `app/src/main/res/raw/` jika belum ada.
2. Masukkan video MP4 dan beri nama persis `anime_bg.mp4`.
3. Video akan diputar berulang tanpa suara sebagai latar. Bila file tidak ada, aplikasi memakai latar ungu animasi sebagai fallback.

## Build APK
1. Buka folder ini di Android Studio.
2. Tunggu Gradle Sync.
3. Pilih **Build > Build APK(s)**.
4. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Project ini adalah kode sumber, bukan APK yang sudah dikompilasi.
